
var bank;
document.getElementById("address").value = defaultAccount;
window.addEventListener('load', function () {
    if (typeof web3 !== 'undefined') {
        console.log('Web3 Detected! ' + web3.currentProvider.constructor.name)
        window.web3 = new Web3(web3.currentProvider);
    } else {
        console.log('No Web3 Detected... using HTTP Provider')
        window.web3 = new Web3(new Web3.providers.HttpProvider(nodeAddress));

        web3.eth.defaultAccount = web3.eth.accounts[0];
        bank = new web3.eth.Contract(contractAbi, contractAddress);
        bank.options.address = web3.eth.defaultAccount;


        web3.eth.subscribe('newBlockHeaders', getBalance);

    }
})
function getBalance() {
    var address, wei, balance
    address = document.getElementById("address").value
    try {
        web3.eth.getBalance(address, function (error, wei) {
            if (!error) {
                var balance = web3.utils.fromWei(wei, 'ether');
                document.getElementById("output").value = balance + " ETH";
            }
        });
    } catch (err) {
        document.getElementById("output").value = err;
    }
}

function getBankBalance() {
    try {
        bank.methods.getbalance().call((err, balance) => {
            document.getElementById("bankBalance").value = balance;
        })
    }
    catch (err) {
        document.getElementById("bankBalance").value = err;
    }
}


function bankCredit() {
    var amount = parseInt(document.getElementById("amount").value);
    if (isNaN(amount)) {
        alert('Please input the transaction amount!');
        return false;
    }
    try {
        log("-------------------------------------------------------");
        log("-> New Credit!");
        bank.methods.credit(amount).send({ from: defaultAccount }, (err, transactionHash) => {
            if (!err) {
                log("-> New Transaction id:")
                log(transactionHash);
                document.getElementById("bankBalance").value = "Waiting for recipt....";
            } else {
                log(err.message);
            }

        }).on("receipt", function (receipt) {
            getBankBalance();
        });

    }
    catch (err) {
        document.getElementById("bankBalance").value = err;
    }
}



function bankDebit() {
    var amount = parseInt(document.getElementById("amount").value);

    if (isNaN(amount)) {
        alert('Please input the transaction amount!');
        return false;
    }
    try {
        log("-------------------------------------------------------");
        log("-> New Debit!");
        bank.methods.debit(amount).send({ from: defaultAccount }, (err, transactionHash) => {
            if (!err) {
                log("-> New Transaction id:")
                log(transactionHash);
                document.getElementById("bankBalance").value = "Waiting for recipt....";
            } else {
                log(err.message);
            }

        }).on("receipt", function (receipt) {
            getBankBalance();
        });
    }
    catch (err) {
        document.getElementById("bankBalance").value = err;
    }
}

function log(msg) {
    var logdiv = document.getElementById("log-div");
    var span = document.createElement("span");
    span.classList.add('d-block');
    span.appendChild(document.createTextNode(msg));
    logdiv.appendChild(span);

}