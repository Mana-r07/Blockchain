
const nodeAddress="http://192.168.0.103:8545";
var defaultAccount = "0xbbfcc4c25ea5ea3186f5aea9ea761ed1f17b1120";
var contractAddress = "0x27aB1A83D6fa80C9eb72c3C9C1A2f2e95e96BF3b";
var contractAbi = [
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [],
        "name": "getbalance",
        "outputs": [
            {
                "internalType": "int256",
                "name": "",
                "type": "int256"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [
            {
                "internalType": "int256",
                "name": "mnt",
                "type": "int256"
            }
        ],
        "name": "debit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "int256",
                "name": "mnt",
                "type": "int256"
            }
        ],
        "name": "credit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];
